---
id: 5
name: 'user | user id | userid | user name | username | uid'
---
The MySQL user to authenticate as.