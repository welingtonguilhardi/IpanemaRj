---
id: 1
name: 'host | server | data source | datasource | addr | address'
---
The hostname of the database you are connecting to. (Default: `localhost`)