---
id: 7
name: 'database | initial catalog'
---
Name of the database to use for this connection (Optional).