---
id: 23
---

#### Configuration Options

This is taken directly from the [mysql.js Readme file](https://github.com/mysqljs/mysql#connection-options), but trimmed to only applicable connection and pooling options, or changed a bit to accomodate legacy settings. 
